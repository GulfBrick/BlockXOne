package main

import (
	"net/http"
	"time"

	"blockxone/internal/app"
	"blockxone/internal/auth"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// registerCompatRoutes adds read-style endpoints that some frontends expect.
//
// The core backend is built around the lifecycle in the deck, but the UI shipped
// with this repo expects a few convenience endpoints (GET by id, etc.).
func registerCompatRoutes(v1 *gin.RouterGroup, a *app.App) {
	// List wallets for current user
	v1.GET("/wallets", func(c *gin.Context) {
		p := auth.MustPrincipal(c)
		rows, err := a.DB.Pool.Query(c.Request.Context(), `
			SELECT id, user_id, address, chain_id, status, created_at, approved_at
			FROM wallets
			WHERE user_id=$1
			ORDER BY created_at DESC
		`, p.UserID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
			return
		}
		defer rows.Close()
		var out []gin.H
		for rows.Next() {
			var id, userID, address, status string
			var chainID int64
			var createdAt time.Time
			var approvedAt *time.Time
			if err := rows.Scan(&id, &userID, &address, &chainID, &status, &createdAt, &approvedAt); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "scan error"})
				return
			}
			out = append(out, gin.H{
				"id":          id,
				"user_id":     userID,
				"address":     address,
				"chain_id":    chainID,
				"status":      status,
				"created_at":  createdAt,
				"approved_at": approvedAt,
			})
		}
		c.JSON(http.StatusOK, out)
	})

	// Offering detail
	v1.GET("/offerings/:id", func(c *gin.Context) {
		id := c.Param("id")
		if _, err := uuid.Parse(id); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		row := a.DB.Pool.QueryRow(c.Request.Context(), `
			SELECT
				o.id, o.status, o.chain_id, o.price::text, o.currency,
				COALESCE(o.min::text,''), COALESCE(o.max::text,''),
				COALESCE(o.start_at, 'epoch'::timestamptz), COALESCE(o.end_at, 'epoch'::timestamptz),
				COALESCE(o.token_contract,''), COALESCE(o.rules_json,'{}'::jsonb),
				a.asset_type, a.name, a.description, COALESCE(a.metadata_json,'{}'::jsonb)
			FROM offerings o
			JOIN assets a ON a.id=o.asset_id
			WHERE o.id=$1
		`, id)
		var offeringID, status, price, currency, minv, maxv, tokenContract, assetType, name, description string
		var chainID int64
		var startAt, endAt time.Time
		var rulesJSON, metaJSON []byte
		if err := row.Scan(&offeringID, &status, &chainID, &price, &currency, &minv, &maxv, &startAt, &endAt, &tokenContract, &rulesJSON, &assetType, &name, &description, &metaJSON); err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "not found"})
			return
		}
		c.JSON(http.StatusOK, gin.H{
			"id":             offeringID,
			"status":         status,
			"chain_id":       chainID,
			"price":          price,
			"currency":       currency,
			"min":            minv,
			"max":            maxv,
			"start_at":       startAt,
			"end_at":         endAt,
			"token_contract": tokenContract,
			"rules_json":     jsonRaw(rulesJSON),
			"asset_type":     assetType,
			"name":           name,
			"description":    description,
			"metadata_json":  jsonRaw(metaJSON),
		})
	})

	// Simple NAV endpoint (MVP)
	v1.GET("/offerings/:id/nav", func(c *gin.Context) {
		id := c.Param("id")
		if _, err := uuid.Parse(id); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		row := a.DB.Pool.QueryRow(c.Request.Context(), `SELECT price::text FROM offerings WHERE id=$1`, id)
		var price string
		if err := row.Scan(&price); err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "not found"})
			return
		}
		c.JSON(http.StatusOK, gin.H{
			"offering_id": id,
			"nav":         price,
			"as_of":       time.Now().UTC(),
		})
	})

	// Subscription detail
	v1.GET("/subscriptions/:id", func(c *gin.Context) {
		p := auth.MustPrincipal(c)
		id := c.Param("id")
		if _, err := uuid.Parse(id); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		row := a.DB.Pool.QueryRow(c.Request.Context(), `
			SELECT id, offering_id, user_id, status, units::text, amount::text, created_at, updated_at
			FROM subscriptions
			WHERE id=$1 AND user_id=$2
		`, id, p.UserID)
		var sid, offeringID, userID, status, units, amount string
		var createdAt, updatedAt time.Time
		if err := row.Scan(&sid, &offeringID, &userID, &status, &units, &amount, &createdAt, &updatedAt); err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "not found"})
			return
		}
		c.JSON(http.StatusOK, gin.H{
			"id":          sid,
			"offering_id": offeringID,
			"user_id":     userID,
			"status":      status,
			"units":       units,
			"amount":      amount,
			"created_at":  createdAt,
			"updated_at":  updatedAt,
		})
	})

	// Marketplace listings list
	v1.GET("/marketplace/listings", func(c *gin.Context) {
		rows, err := a.DB.Pool.Query(c.Request.Context(), `
			SELECT id, offering_id, seller_user_id, seller_wallet_id, units::text, price::text, currency, status, created_at
			FROM marketplace_listings
			ORDER BY created_at DESC
			LIMIT 200
		`)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
			return
		}
		defer rows.Close()
		var out []gin.H
		for rows.Next() {
			var id, offeringID, sellerUserID, sellerWalletID, units, price, currency, status string
			var createdAt time.Time
			if err := rows.Scan(&id, &offeringID, &sellerUserID, &sellerWalletID, &units, &price, &currency, &status, &createdAt); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "scan error"})
				return
			}
			out = append(out, gin.H{
				"id":               id,
				"offering_id":      offeringID,
				"seller_user_id":   sellerUserID,
				"seller_wallet_id": sellerWalletID,
				"units":            units,
				"price":            price,
				"currency":         currency,
				"status":           status,
				"created_at":       createdAt,
			})
		}
		c.JSON(http.StatusOK, out)
	})

	// Marketplace RFQs list
	v1.GET("/marketplace/rfq", func(c *gin.Context) {
		rows, err := a.DB.Pool.Query(c.Request.Context(), `
			SELECT id, offering_id, buyer_user_id, buyer_wallet_id, units::text, max_price::text, currency, status, created_at
			FROM marketplace_rfqs
			ORDER BY created_at DESC
			LIMIT 200
		`)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
			return
		}
		defer rows.Close()
		var out []gin.H
		for rows.Next() {
			var id, offeringID, buyerUserID, buyerWalletID, units, maxPrice, currency, status string
			var createdAt time.Time
			if err := rows.Scan(&id, &offeringID, &buyerUserID, &buyerWalletID, &units, &maxPrice, &currency, &status, &createdAt); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "scan error"})
				return
			}
			out = append(out, gin.H{
				"id":              id,
				"offering_id":     offeringID,
				"buyer_user_id":   buyerUserID,
				"buyer_wallet_id": buyerWalletID,
				"units":           units,
				"max_price":       maxPrice,
				"currency":        currency,
				"status":          status,
				"created_at":      createdAt,
			})
		}
		c.JSON(http.StatusOK, out)
	})

	// Transactions list (MVP: transfers table)
	v1.GET("/transactions", func(c *gin.Context) {
		p := auth.MustPrincipal(c)
		rows, err := a.DB.Pool.Query(c.Request.Context(), `
			SELECT t.offering_id, t.from_wallet, t.to_wallet, t.amount::text, COALESCE(t.tx_hash,''), t.occurred_at
			FROM transfers t
			LEFT JOIN wallets wf ON wf.address=t.from_wallet
			LEFT JOIN wallets wt ON wt.address=t.to_wallet
			WHERE wf.user_id=$1 OR wt.user_id=$1
			ORDER BY t.occurred_at DESC
			LIMIT 200
		`, p.UserID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "db error"})
			return
		}
		defer rows.Close()
		var out []gin.H
		for rows.Next() {
			var offeringID, fromAddr, toAddr, amount, txHash string
			var occurredAt time.Time
			if err := rows.Scan(&offeringID, &fromAddr, &toAddr, &amount, &txHash, &occurredAt); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "scan error"})
				return
			}
			out = append(out, gin.H{
				"offering_id": offeringID,
				"from_wallet": fromAddr,
				"to_wallet":   toAddr,
				"amount":      amount,
				"tx_hash":     txHash,
				"occurred_at": occurredAt,
			})
		}
		c.JSON(http.StatusOK, out)
	})

	// Redemption detail
	v1.GET("/redemptions/:id", func(c *gin.Context) {
		p := auth.MustPrincipal(c)
		id := c.Param("id")
		if _, err := uuid.Parse(id); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		row := a.DB.Pool.QueryRow(c.Request.Context(), `
			SELECT id, offering_id, user_id, status, amount_tokens::text, amount_cash::text, created_at, updated_at
			FROM redemptions
			WHERE id=$1 AND user_id=$2
		`, id, p.UserID)
		var rid, offeringID, userID, status, amtTok, amtCash string
		var createdAt, updatedAt time.Time
		if err := row.Scan(&rid, &offeringID, &userID, &status, &amtTok, &amtCash, &createdAt, &updatedAt); err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "not found"})
			return
		}
		c.JSON(http.StatusOK, gin.H{
			"id":            rid,
			"offering_id":   offeringID,
			"user_id":       userID,
			"status":        status,
			"amount_tokens": amtTok,
			"amount_cash":   amtCash,
			"created_at":    createdAt,
			"updated_at":    updatedAt,
		})
	})
}

// jsonRaw ensures we return a value that serializes as JSON, not base64.
func jsonRaw(b []byte) any {
	if len(b) == 0 {
		return gin.H{}
	}
	return jsonBytes(b)
}

// jsonBytes is a small alias type used to embed raw JSON in Gin responses.
type jsonBytes []byte

func (j jsonBytes) MarshalJSON() ([]byte, error) { return j, nil }
