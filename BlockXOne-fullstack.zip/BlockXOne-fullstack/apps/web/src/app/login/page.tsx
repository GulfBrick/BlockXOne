'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'

import { useAuth } from '@/lib/auth-context-v2'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'

type QuickUser = {
  label: string
  userId: string
  email: string
  roles: string[]
  redirect: string
}

export default function LoginPage() {
  const router = useRouter()
  const { user, loginAs, logout } = useAuth()

  const quickUsers = useMemo<QuickUser[]>(
    () => [
      {
        label: 'Investor',
        userId: '11111111-1111-1111-1111-111111111111',
        email: 'investor@blockxone.local',
        roles: ['Investor'],
        redirect: '/investor/market',
      },
      {
        label: 'Offering Manager',
        userId: '22222222-2222-2222-2222-222222222222',
        email: 'offering@blockxone.local',
        roles: ['OfferingManager'],
        redirect: '/wm',
      },
      {
        label: 'Compliance Officer',
        userId: '33333333-3333-3333-3333-333333333333',
        email: 'compliance@blockxone.local',
        roles: ['ComplianceOfficer'],
        redirect: '/compliance',
      },
      {
        label: 'Issuer/Fund Manager',
        userId: '44444444-4444-4444-4444-444444444444',
        email: 'issuer@blockxone.local',
        roles: ['IssuerFundManager'],
        redirect: '/wm',
      },
      {
        label: 'Transfer Agent',
        userId: '55555555-5555-5555-5555-555555555555',
        email: 'ta@blockxone.local',
        roles: ['TransferAgent'],
        redirect: '/wm',
      },
      {
        label: 'Tokenisation Agent',
        userId: '66666666-6666-6666-6666-666666666666',
        email: 'token@blockxone.local',
        roles: ['TokenisationAgent'],
        redirect: '/wm',
      },
      {
        label: 'Super Admin',
        userId: '77777777-7777-7777-7777-777777777777',
        email: 'admin@blockxone.local',
        roles: ['SuperAdmin'],
        redirect: '/admin',
      },
    ],
    []
  )

  const [customUserId, setCustomUserId] = useState<string>(crypto.randomUUID())
  const [customEmail, setCustomEmail] = useState<string>('')
  const [customRoles, setCustomRoles] = useState<string>('Investor')
  const [status, setStatus] = useState<string>('')

  async function doLogin(u: { userId: string; email: string; roles: string[]; redirect: string }) {
    setStatus('Logging in…')
    try {
      await loginAs(u.userId, u.email, u.roles)
      setStatus('')
      router.push(u.redirect)
    } catch (e: any) {
      setStatus(e?.message || 'Login failed')
    }
  }

  async function doCustomLogin() {
    const roles = customRoles
      .split(',')
      .map((r) => r.trim())
      .filter(Boolean)

    if (!customEmail || !roles.length) {
      setStatus('Email and roles are required')
      return
    }

    await doLogin({ userId: customUserId, email: customEmail, roles, redirect: '/' })
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-3xl space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">BlockXOne</h1>
          <p className="text-muted-foreground">
            Dev login (RBAC via X-Dev-* headers). Use the quick roles below to exercise the full lifecycle.
          </p>
        </div>

        {user ? (
          <Card className="p-4 flex items-center justify-between">
            <div className="space-y-1">
              <div className="text-sm">Signed in as</div>
              <div className="font-mono text-sm">{user.email}</div>
              <div className="text-xs text-muted-foreground">Roles: {user.roles.join(', ') || 'none'}</div>
            </div>
            <Button
              variant="secondary"
              onClick={() => {
                logout()
                setStatus('Logged out')
              }}
            >
              Logout
            </Button>
          </Card>
        ) : null}

        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-semibold">Quick login</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {quickUsers.map((u) => (
              <Button key={u.userId} onClick={() => doLogin(u)}>
                {u.label}
              </Button>
            ))}
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-semibold">Custom dev login</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm">User ID (UUID)</label>
              <Input value={customUserId} onChange={(e) => setCustomUserId(e.target.value)} placeholder="UUID" />
              <Button variant="ghost" onClick={() => setCustomUserId(crypto.randomUUID())}>
                Generate
              </Button>
            </div>
            <div className="space-y-2">
              <label className="text-sm">Email</label>
              <Input value={customEmail} onChange={(e) => setCustomEmail(e.target.value)} placeholder="you@example.com" />
              <label className="text-sm">Roles (comma-separated)</label>
              <Input
                value={customRoles}
                onChange={(e) => setCustomRoles(e.target.value)}
                placeholder="Investor, ComplianceOfficer, ..."
              />
              <Button onClick={doCustomLogin}>Login</Button>
            </div>
          </div>
        </Card>

        {status ? <div className="text-center text-sm text-muted-foreground">{status}</div> : null}
      </div>
    </div>
  )
}
