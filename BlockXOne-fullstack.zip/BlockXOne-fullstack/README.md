# BlockXOne (full-stack dev monorepo)

This repository bundles **BlockXOne**'s:

- **Backend API + worker** (Go + Postgres + NATS)
- **Frontend web app** (Next.js)
- **MetaMask wallet connect + multi-chain selector**
- **Onramp/Offramp stub endpoints** (so UX works in dev now)

> Notes
> - The backend’s **on-chain adapter is in mock mode by default** (`CHAIN_MODE=mock`). That keeps the platform fully usable while we wire real testnet contracts in the next iteration.
> - The frontend includes a **Dev Login** page so you can quickly assume roles and exercise end-to-end flows without building a full identity system yet.

## Prerequisites

- Node.js 18+
- Go 1.22+ (or newer)
- Docker Desktop (for Postgres + NATS)

## Quick start (dev)

### 1) Start infrastructure (Postgres + NATS)

```bash
cd backend
docker compose up -d
```

### 2) Configure backend env

```bash
cd backend
cp .env.example .env
```

### 3) Run migrations + seed demo users/roles

```bash
cd backend
make migrate
make seed
```

### 4) Start backend API + worker (two terminals)

Terminal A:
```bash
cd backend
make api
```

Terminal B:
```bash
cd backend
make worker
```

Backend runs on: `http://localhost:8080`

You can open the backend dev console at:
- `http://localhost:8080/console`

### 5) Start the frontend

```bash
cd apps/web
npm install
npm run dev
```

Frontend runs on: `http://localhost:5000`

## Using the platform (dev)

1) Open `http://localhost:5000/login`
2) Use one of the **Quick Login** buttons (Investor / Compliance / Offering Manager / Issuer)
3) In the top navbar:
   - Click **Connect MetaMask**
   - Choose your network from the chain dropdown
   - Click **Link 0x…** to sign and link your wallet to BlockXOne
4) Use the backend dev console (`/console`) to create offerings, approve wallets, etc.

## Key API additions in this build

- `GET /v1/chains` — chain list (mainnets + testnets) with RPC + explorer metadata
- `POST /v1/onramp/quote` — stub
- `POST /v1/onramp/session` — stub
- `POST /v1/offramp/quote` — stub
- `POST /v1/offramp/payout` — stub

Additional **UI-compatibility endpoints** were added so the existing frontend API client can load data cleanly:

- `GET /v1/offerings/:id`
- `GET /v1/offerings/:id/nav`
- `GET /v1/subscriptions/:id`
- `GET /v1/wallets`
- `GET /v1/marketplace/listings`
- `GET /v1/marketplace/rfq`
- `GET /v1/transactions`
- `GET /v1/redemptions/:id`

## Next step: real testnet tokenization

When you’re ready, we’ll implement the EVM adapter to:

- Deploy an offering token contract per offering (testnet)
- Whitelist wallets, mint/burn, freeze, and force-transfer
- Run an indexer to reconcile on-chain events into holdings/cap-table

